<?php
/**
 * Copyright © Viha Digital Commerce All rights reserved.
 * See COPYING.txt for license details.
 */
use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Vdcstore_LiveSite', __DIR__);

