<?php

namespace Vdcstore\AutoInvoice\Block;

use Magento\Framework\DB\TransactionFactory;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\View\Element\Template\Context;
use Magento\Sales\Api\InvoiceRepositoryInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Convert\OrderFactory;
use Magento\Sales\Model\Order\Email\Sender\ShipmentSender;
use Magento\Sales\Model\ResourceModel\Order\Invoice\CollectionFactory;
use Magento\Sales\Model\Service\InvoiceService;

class Shipment extends \Magento\Framework\View\Element\Template
{
    /**
     * @var CollectionFactory
     */
    protected $_invoiceCollectionFactory;
    /**
     * @var InvoiceRepositoryInterface
     */
    protected $_invoiceRepository;
    /**
     * @var InvoiceService
     */
    protected $_invoiceService;
    /**
     * @var TransactionFactory
     */
    protected $_transactionFactory;
    /**
     * @var OrderRepositoryInterface
     */
    protected $_orderRepository;

    /**
     * @param Context $context
     * @param OrderRepositoryInterface $orderRepository
     * @param OrderFactory $convertOrderFactory
     * @param TransactionFactory $transactionFactory
     * @param ShipmentSender $shipmentSender
     * @param ManagerInterface $messageManager
     * @param CollectionFactory $invoiceCollectionFactory
     * @param InvoiceService $invoiceService
     * @param InvoiceRepositoryInterface $invoiceRepository
     * @param array $data
     */
    public function __construct(
        Context                    $context,
        OrderRepositoryInterface   $orderRepository,
        OrderFactory               $convertOrderFactory,
        TransactionFactory         $transactionFactory,
        ShipmentSender             $shipmentSender,
        ManagerInterface           $messageManager,
        CollectionFactory          $invoiceCollectionFactory,
        InvoiceService             $invoiceService,
        InvoiceRepositoryInterface $invoiceRepository,
        array                      $data = []
    ) {
        $this->orderRepository = $orderRepository;
        $this->orderConverter = $convertOrderFactory->create();
        $this->transactionFactory = $transactionFactory;
        $this->messageManager = $messageManager;
        $this->shipmentSender = $shipmentSender;
        $this->_invoiceCollectionFactory = $invoiceCollectionFactory;
        $this->_invoiceService = $invoiceService;
        $this->_transactionFactory = $transactionFactory;
        $this->_invoiceRepository = $invoiceRepository;
        $this->_orderRepository = $orderRepository;
        parent::__construct($context, $data);
    }

    /**
     * Generate shipment orders
     *
     * @param int $orderId
     * @return bool|string
     */
    public function generateShipment($orderId)
    {
        try {
            $order = $this->orderRepository->get($orderId);
            if (!$order->getId()) {
                throw new \Magento\Framework\Exception\LocalizedException(__('The order no longer exists.'));
            }
            if ($order->canShip()) {
                $shipment = $this->orderConverter->toShipment($order);
                foreach ($order->getAllItems() as $orderItem) {
                    if (!$orderItem->getQtyToShip() || $orderItem->getIsVirtual()) {
                        continue;
                    }
                    $qtyShipped = $orderItem->getQtyToShip();
                    $shipmentItem = $this->orderConverter->itemToShipmentItem($orderItem)->setQty($qtyShipped);
                    $shipment->addItem($shipmentItem);
                }
                $shipment->register();
                $shipment->getOrder()->setIsInProcess(true);
                try {
                    $transaction = $this->transactionFactory->create()->addObject($shipment)
                        ->addObject($shipment->getOrder())
                        ->save();
                    $shipmentId = $shipment->getIncrementId();
                } catch (\Exception $e) {
                    $this->messageManager->addError(__('We can\'t generate shipment.'));
                }
                if ($shipment) {
                    try {
                        $this->shipmentSender->send($shipment);
                    } catch (\Exception $e) {
                        $this->messageManager->addError(__('We can\'t send the shipment right now.'));
                    }
                }
                return $shipmentId;
            }
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
        return true;
    }

    /**
     * Create invoice order
     *
     * @param array $orderId
     * @return \Magento\Sales\Api\Data\InvoiceInterface|\Magento\Sales\Model\Order\Invoice|void|null
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function createInvoice($orderId)
    {
        try {
            $order = $this->_orderRepository->get($orderId);
            if ($order) {
                $invoices = $this->_invoiceCollectionFactory->create()
                    ->addAttributeToFilter('order_id', ['eq' => $order->getId()]);
                $invoices->getSelect()->limit(1);
                if ((int)$invoices->count() !== 0) {
                    $invoices = $invoices->getFirstItem();
                    $invoice = $this->_invoiceRepository->get($invoices->getId());
                    return $invoice;
                }
                if (!$order->canInvoice()) {
                    return null;
                }
                $invoice = $this->_invoiceService->prepareInvoice($order);
                $invoice->setRequestedCaptureCase(\Magento\Sales\Model\Order\Invoice::CAPTURE_ONLINE);
                $invoice->register();
                $invoice->getOrder()->setCustomerNoteNotify(false);
                $invoice->getOrder()->setIsInProcess(true);
                $order->addStatusHistoryComment(__('Automatically Invoice'), false);
                $transactionSave = $this->_transactionFactory->create()
                                        ->addObject($invoice)
                                        ->addObject($invoice->getOrder());
                $transactionSave->save();
                return $invoice;
            }
        } catch (\Exception $e) {
            throw new \Magento\Framework\Exception\LocalizedException(__($e->getMessage()));
        }
    }
}
