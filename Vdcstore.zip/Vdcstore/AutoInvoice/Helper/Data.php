<?php
namespace Vdcstore\AutoInvoice\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;
use Magento\Customer\Model\Context;
use Magento\Framework\App\Area;
use Magento\Framework\App\Config\ScopeConfigInterface;

class Data extends AbstractHelper
{
    public const XML_PATH_MINORDERAMT = 'autoinvoice/';

    /**
     * @var ScopeConfigInterface
     */
    public $scopeConfig;
    /**
     * @var \Magento\Framework\App\Http\Context
     */
    public $httpContext;
    /**
     * @var array
     */
    public $productCache = [];

    /**
     * @param ScopeConfigInterface $scopeConfig
     * @param \Magento\Framework\App\Http\Context $httpContext
     */
    public function __construct(
        ScopeConfigInterface                $scopeConfig,
        \Magento\Framework\App\Http\Context $httpContext
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->httpContext = $httpContext;
    }

    /**
     * Get general configuration
     *
     * @param int $code
     * @param int $storeId
     * @return mixed
     */
    public function getGeneralConfig($code, $storeId = null)
    {
        return $this->getConfigValue(self::XML_PATH_MINORDERAMT . 'general/' . $code, $storeId);
    }

    /**
     * Get configuration value
     *
     * @param int $field
     * @param int $storeId
     * @return mixed
     */
    public function getConfigValue($field, $storeId = null)
    {
        return $this->scopeConfig->getValue($field, ScopeInterface::SCOPE_STORE, $storeId);
    }
}
