<?php
namespace Vdcstore\CustomPrice\Block\Catalog\Product;

use Magento\Catalog\Block\Product\Context;
use Magento\Catalog\Block\Product\AbstractProduct;
use Vdcstore\CustomPrice\Helper\Data;

class View extends AbstractProduct
{
    protected $helperData;

    public function __construct(
        Data $helperData,
        Context $context,
        array $data
    ){
        $this->helperData = $helperData;
        parent::__construct($context, $data);
    }

    public function getSku(){
        return $this->helperData->getGeneralConfig('configsku');
    }

    public function getEnable(){
        return $this->helperData->getGeneralConfig('enable');
    }
}
