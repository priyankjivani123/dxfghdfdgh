<?php
namespace Vdcstore\LiveDemo\Block;

use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Element\Template;
use Magento\Store\Model\StoreManagerInterface;
/**
 *
 */
class DemoLink extends Template
{
    /**
     * @var Registry
     */
    protected $_registry;

    protected $_storeManager;

    /**
     * @param Context $context
     * @param Registry $registry
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        StoreManagerInterface $storeManager,
        array $data = []
    )
    {
        $this->_registry = $registry;
        $this->_storeManager = $storeManager;
        parent::__construct($context, $data);
    }

    /**
     * @return DemoLink
     */
    public function _prepareLayout()
    {
        return parent::_prepareLayout();
    }

    /**
     * @return mixed|null
     */
    public function getCurrentProduct()
    {
        return $this->_registry->registry('current_product');
    }
    public function getBaseUrlWeb(){
        return $this->_storeManager->getStore()->getBaseUrl();
    }
}
