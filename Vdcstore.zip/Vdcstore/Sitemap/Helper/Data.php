<?php
namespace Vdcstore\Sitemap\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{
    const XML_PATH_VDCSTORE_SITEMAP = 'vdcstore_sitemap/';
    /**
     * @param $field
     * @param $storeCode
     * @return mixed
     */
    public function getConfigValue($field, $storeCode = null)
    {
        return $this->scopeConfig->getValue($field, ScopeInterface::SCOPE_STORE, $storeCode);
    }

    /**
     * @param $fieldid
     * @param $storeCode
     * @return mixed
     */
    public function getGeneralConfig($fieldid, $storeCode = null)
    {
        return $this->getConfigValue(self::XML_PATH_VDCSTORE_SITEMAP . 'general/' . $fieldid, $storeCode);
    }

    /**
     * @param $fieldid
     * @param $storeCode
     * @return mixed
     */
    public function getCategoriesConfig($fieldid, $storeCode = null)
    {
        return $this->getConfigValue(self::XML_PATH_VDCSTORE_SITEMAP . 'categories/' . $fieldid, $storeCode);
    }

    /**
     * @param $fieldid
     * @param $storeCode
     * @return mixed
     */
    public function getProductsConfig($fieldid, $storeCode = null)
    {
        return $this->getConfigValue(self::XML_PATH_VDCSTORE_SITEMAP . 'products/' . $fieldid, $storeCode);
    }

    /**
     * @param $fieldid
     * @param $storeCode
     * @return mixed
     */
    public function getCmsPagesConfig($fieldid, $storeCode = null)
    {
        return $this->getConfigValue(self::XML_PATH_VDCSTORE_SITEMAP . 'cms_pages/' . $fieldid, $storeCode);
    }
}
