<?php

namespace Vdcstore\CustomPrice\Plugin\Product;

use Vdcstore\CustomPrice\Helper\Data;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;

class View
{
    protected $helperData;

    public function __construct(
        Data $helperData
    ){
        $this->helperData = $helperData;
    }
    public function afterShouldRenderQuantity(\Magento\Catalog\Block\Product\View $subject, $result)
    {
        $enable = $this->helperData->getGeneralConfig('enable');
        $sku = $this->helperData->getGeneralConfig('configsku');

        if ($enable == '1' && $subject->getProduct()->getSku() == $sku) {
            return false;
        }
        return $result;
    }
}
