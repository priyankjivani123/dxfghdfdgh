<?php

namespace Vdcstore\Sitemap\Block;

use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Store\Model\StoreManagerInterface;
use Vdcstore\Sitemap\Helper\Data;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory as CategoryCollectionFactory;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\Cms\Model\ResourceModel\Page\CollectionFactory as PageCollectionFactory;

class Sitemap extends Template
{

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var CategoryCollectionFactory
     */
    protected $categoryCollectionFactory;

    /**
     * @var ProductCollectionFactory
     */
    protected $productCollectionFactory;

    /**
     * @var Data
     */
    protected $helperData;

    /**
     * @var ProductMetadataInterface
     */
    protected $productMetadata;

    /**
     * @var PageCollectionFactory
     */
    protected $pageCollectionFactory;

    /**
     * @param Context $context
     * @param StoreManagerInterface $storeManager
     * @param Data $helperData
     * @param CategoryCollectionFactory $categoryCollectionFactory
     * @param ProductCollectionFactory $productCollectionFactory
     * @param PageCollectionFactory $pageCollectionFactory
     * @param ProductMetadataInterface $productMetadata
     * @param array $data
     */
    public function __construct(
        Context                   $context,
        StoreManagerInterface     $storeManager,
        Data                      $helperData,
        CategoryCollectionFactory $categoryCollectionFactory,
        ProductCollectionFactory  $productCollectionFactory,
        PageCollectionFactory     $pageCollectionFactory,
        ProductMetadataInterface  $productMetadata,
        array                     $data = []
    ) {
        parent::__construct($context, $data);

        $this->helperData = $helperData;
        $this->categoryCollectionFactory = $categoryCollectionFactory;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->pageCollectionFactory = $pageCollectionFactory;
        $this->storeManager = $storeManager;
        $this->productMetadata = $productMetadata;
    }

    /**
     * @return \Magento\Catalog\Model\ResourceModel\Category\Collection|\Magento\Framework\Data\Collection\AbstractDb
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getCategories()
    {

        $entityField = $this->productMetadata->getEdition() != 'Community' ? 'row_id' : 'entity_id';
        $excludeIds = $this->helperData->getCategoriesConfig('exclude_categories');
        $excludeIds = explode(',', $excludeIds ?? '');
        
        $currentStore = $this->storeManager->getStore();
        $storeCategories = $this->categoryCollectionFactory->create()
            ->addAttributeToSelect('*')
            ->addAttributeToFilter('is_active', 1)
            ->addFieldToFilter($entityField, array('nin' => $excludeIds))
            ->setStore($currentStore);
        return $storeCategories;
    }

    /**
     * @return \Magento\Catalog\Model\ResourceModel\Product\Collection
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getProducts()
    {

        if ($this->helperData->getProductsConfig('max_product')) {
            $limitProduct = $this->helperData->getProductsConfig('max_product');
        } else {
            $limitProduct = 50000;
        }

        $currentStore = $this->storeManager->getStore()->getId();
        $collection = $this->productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->addAttributeToFilter('status', 1);
        $collection->addAttributeToFilter('visibility', [
            'in' => [
                \Magento\Catalog\Model\Product\Visibility::VISIBILITY_IN_CATALOG,
                \Magento\Catalog\Model\Product\Visibility::VISIBILITY_BOTH
            ]
        ]);
        $collection->addAttributeToSort('name', 'ASC');
        $collection->setPageSize($limitProduct);
        $collection->addStoreFilter($currentStore);

        return $collection;
    }

    /**
     * @return \Magento\Cms\Model\ResourceModel\Page\Collection
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getCmsPages()
    {

        $excludeCMSPages = [];
        $excludeCMSPagesConfig = $this->helperData->getCmsPagesConfig('exclude_cms_pages');
        if ($excludeCMSPagesConfig !== null) {
            $excludeCMSPagesConfigList = explode(",", $excludeCMSPagesConfig);
            foreach ($excludeCMSPagesConfigList as $item) {
                $excludeCMSPages[] = trim($item);
            }
        }

        $currentStore = $this->storeManager->getStore()->getId();
        $collection = $this->pageCollectionFactory->create();
        $collection->setOrder('title', 'ASC');
        $collection->addFilter('is_active', '1');
        $collection->addStoreFilter($currentStore);

        if (!empty($excludeCMSPages)) {
            $collection->addFilter('identifier', ['nin' => $excludeCMSPages], 'public');
        }

        return $collection;
    }

    /**
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getBaseUrl()
    {
        return $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_WEB);
    }

    /**
     * @return mixed
     */
    public function getCategoriesEnable()
    {
        return $this->helperData->getCategoriesConfig('enable_categories');
    }

    /**
     * @return mixed
     */
    public function getProductsEnable()
    {
        return $this->helperData->getProductsConfig('enable_products');
    }

    /**
     * @return mixed
     */
    public function getCmsPagesEnable()
    {
        return $this->helperData->getCmsPagesConfig('enable_cms_pages');
    }

    /**
     * @return mixed|string
     */
    public function getCategoriesHeaderTitle()
    {
        $categoriesHeader = $this->helperData->getCategoriesConfig('category_header');
        if ($categoriesHeader == '') {
            $header = "Categories";
        } else {
            $header = $categoriesHeader;
        }
        return $header;
    }

    /**
     * @return mixed|string
     */
    public function getProductsHeaderTitle()
    {
        $productsHeader = $this->helperData->getProductsConfig('product_header');
        if ($productsHeader == '') {
            $header = "Products";
        } else {
            $header = $productsHeader;
        }
        return $header;
    }

    /**
     * @return mixed|string
     */
    public function getCmsPagesHeaderTitle()
    {
        $cmsPagesHeader = $this->helperData->getCmsPagesConfig('cms_header');
        if ($cmsPagesHeader == '') {
            $header = "CMS Pages";
        } else {
            $header = $cmsPagesHeader;
        }
        return $header;
    }

    /**
     * @return mixed
     */
    public function getShowSearchField()
    {
        return $this->helperData->getGeneralConfig('show_search');
    }
}
