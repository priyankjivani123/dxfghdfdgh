<?php
namespace Vdcstore\AutoInvoice\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order;
use Vdcstore\AutoInvoice\Block\Index;
use Vdcstore\AutoInvoice\Block\Shipment;

class OrderObserver implements ObserverInterface
{
    /**
     * @param Shipment $BlockShipment
     * @param Index $IndexBlock
     * @param OrderRepositoryInterface $orderRepository
     * @param Order $order
     */
    public function __construct(
        Shipment                 $BlockShipment,
        Index                    $IndexBlock,
        OrderRepositoryInterface $orderRepository,
        Order                    $order
    ) {
        $this->BlockShipment = $BlockShipment;
        $this->IndexBlock = $IndexBlock;
        $this->orderRepository = $orderRepository;
        $this->order = $order;
    }

    /**
     * Get selected payment methods
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $status = $this->IndexBlock->getEnabl();
        if ($status == '1') {
            $orderId = $observer->getEvent()->getOrder()->getId();
            $getAutoInvoiceGeneration = $this->IndexBlock->getAutoInvoiceGeneration();
            $getAutoShipmentGeneration = $this->IndexBlock->getAutoShipmentGeneration();
            $getSelectedPaaymentMethod = $this->IndexBlock->getSelectedPaaymentMethod();
            $getSelectedPaaymentMethodArray = explode(",", $getSelectedPaaymentMethod);
            $order = $this->orderRepository->get($orderId);
            $orderIncrementId = $order->getIncrementId();
            $order = $this->order->loadByIncrementId($orderIncrementId);
            $payment = $order->getPayment();
            $method = $payment->getMethod();
            if (in_array($method, $getSelectedPaaymentMethodArray)) {
                if ($getAutoInvoiceGeneration == '1') {
                    $this->BlockShipment->createInvoice($orderId);
                }
                if ($getAutoShipmentGeneration == '1') {
                    $this->BlockShipment->generateShipment($orderId);
                }
            }
        }
    }
}
