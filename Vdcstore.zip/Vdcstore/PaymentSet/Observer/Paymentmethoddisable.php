<?php
 
namespace Vdcstore\PaymentSet\Observer;
 
use Magento\Framework\Event\ObserverInterface;
use Magento\Payment\Api\PaymentMethodListInterface;


class Paymentmethoddisable implements ObserverInterface
{
    protected $_storeManager;
    private $paymentMethodList;
    protected $storeManager;


    public function __construct(
      
        \Magento\Store\Model\StoreManagerInterface $storeManager,
         PaymentMethodListInterface $paymentMethodList
    )
    {
        
        $this->_storeManager = $storeManager;
        $this->paymentMethodList = $paymentMethodList;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
       
        $currentStoreId = $this->_storeManager->getStore()->getId();

        $activePaymentMethodList = $this->paymentMethodList->getActiveList($currentStoreId);

        $currencyCode = $this->_storeManager->getStore()->getCurrentCurrency()->getCode();
        if($currencyCode == 'USD'){

            if($observer->getEvent()->getMethodInstance()->getCode()=="razorpay"){  // Here you can replace required payment method code
                $checkResult = $observer->getEvent()->getResult();
                $checkResult->setData('is_available', false); 
            }

        }elseif($currencyCode == 'INR'){

            if($observer->getEvent()->getMethodInstance()->getCode()=="paypal_express"){  // Here you can replace required payment method code
                $checkResult = $observer->getEvent()->getResult();
                $checkResult->setData('is_available', false); 
            }

        }
       
    }
}