<?php

namespace Vdcstore\CustomPrice\Pricing\Render;

use Magento\Catalog\Pricing\Price;
use Magento\Framework\Pricing\Render;
use Magento\Framework\Pricing\Render\PriceBox as BasePriceBox;
use Magento\Msrp\Pricing\Price\MsrpPrice;
use Vdcstore\CustomPrice\Helper\Data;
use Magento\Framework\View\Element\Template\Context;
use Magento\Catalog\Model\Product;

use Magento\Catalog\Model\Product\Pricing\Renderer\SalableResolverInterface;
use Magento\Framework\Pricing\SaleableInterface;
use Magento\Framework\Pricing\Price\PriceInterface;
use Magento\Framework\Pricing\Render\RendererPool;
use Magento\Framework\App\ObjectManager;
use Magento\Catalog\Pricing\Price\MinimalPriceCalculatorInterface;

class FinalPriceBox extends \Magento\Catalog\Pricing\Render\FinalPriceBox
{
    protected $helperData;
    protected $product;

    public function __construct(
        Context $context,
        Product $product,
        Data $helperData,
        SaleableInterface $saleableItem,
        PriceInterface $price,
        RendererPool $rendererPool,
        array $data = [],
        SalableResolverInterface $salableResolver = null,
        MinimalPriceCalculatorInterface $minimalPriceCalculator = null
    ){
        $this->helperData = $helperData;
        $this->product = $product;
        parent::__construct($context, $saleableItem, $price, $rendererPool, $data);
    }

    protected function wrapResult($html)
    {
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/price.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $logger->info('----------------- file call --------------- ');

        $enable = $this->helperData->getGeneralConfig('enable');
        $sku = $this->helperData->getGeneralConfig('configsku');
        $currentid = $this->getRequest()->getParam('id');
        $product = $this->product->load($currentid);
        $currentSku =  $product->getSku();

        if ($enable == '1' && $currentSku == $sku) {
            $logger->info('----------------- get daata --------------- ');
            return '';
        }
        return $html;
    }
}
