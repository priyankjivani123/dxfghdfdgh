<?php

namespace Vdcstore\CustomPrice\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use \Magento\Framework\App\RequestInterface;
use Vdcstore\CustomPrice\Helper\Data;

class CustomPrice implements ObserverInterface
{
    protected $request;

    protected $helperData;

    public function __construct(
        Data $helperData,
        RequestInterface $request
    ){
        $this->helperData = $helperData;
        $this->request = $request;
    }

    public function execute(Observer $observer) {

        $enable = $this->helperData->getGeneralConfig('enable');
        if ($enable == '1') {
            $price = $this->request->getParam('vdc_price');
            $item = $observer->getEvent()->getData('quote_item');
            $item = ( $item->getParentItem() ? $item->getParentItem() : $item );
            $item->setCustomPrice($price);
            $item->setOriginalCustomPrice($price);
            $item->getProduct()->setIsSuperMode(true);
        }
    }
}
